#include "Reactor.h"
#include "ReactorImpl.h"
#include "SelectReactor.h"

Reactor::Reactor()
{
	pReactorImpl = new SelectReactor;
}

Reactor::~Reactor()
{
	delete pReactorImpl;
}

void Reactor::addEventHandle(EventHandle* eveHandle, EventType eveType)
{
	//pReactorImpl->addEventHandle(eveHandle, eveType);
}

void Reactor::removeEventHandle(EventHandle* eveHandle)
{
	//pReactorImpl->removeEventHandle();
}

void Reactor::run()
{
	//pReactorImpl->run();
}

Reactor* Reactor::getInstance()
{
	/*static Reactor _reactor;

	return &_reactor;*/
}