#ifndef LOGHANDLE_20110526 
#define LOGHANDLE_20110526

#include "Reactor.h"
#include "EventHandle.h"
#include "EventType.h"

class LogHandle: public EventHandle
{
public:
	LogHandle(SOCKET _connSock): connSocket(_connSock)
	{
		Reactor::getInstance()->addEventHandle(this, READ_EVENT);
	}

	~LogHandle()
	{
		Reactor::getInstance()->removeEventHandle(this);
	}

	size_t handleEvent(Reactor::EventType eveType)
	{
		assert(eveType == READ_EVENT);


	}

public:
	SOCKET connSocket;
}

#endif