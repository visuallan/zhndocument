#include "SelectReactor.h"


void SelectReactor::addEventHandle(EventHandle* eveHandle, EventType eveType)
{
	eveHandleMap[eveHandle] = eveType;
}

void SelectReactor::removeEventHandle(EventHandle* eveHandle)
{
	map<EventHandle*, EventType>::iterator iter = eveHandleMap.find(eveHandle);

	if(iter != eveHandleMap.end())
	{
		eveHandleMap.erase(iter);
	}
}

void SelectReactor::run()
{
	FD_SET fRead;
	FD_SET fWrite;
	FD_SET fExcept;

	map<EventHandle*, EventType>::iterator iter;

	for(; iter != eveHandleMap.end(); ++iter)
	{
		if(iter->second == READ_EVENT)
		{
			FD_SET((iter->first)->getSocket(), &fRead);
		}

		if(iter->second == WRITE_EVENT)
		{
			FD_SET((iter->first)->getSocket(), &fWrite);
		}

		if(iter->second == EXCEPT_EVENT)
		{
			FD_SET((iter->first)->getSocket(), &fExcept);
		}
	}

	int eveCount = select(0, &fRead, &fWrite, &fExcept, NULL);

	if(eveCount > 0)
	{
		iter = eveHandleMap.begin();

		for(; iter != eveHandleMap.end(); ++iter)
		{
			if(FD_ISSET((iter->first)->getSocket(), &fRead))
			{
				(iter->first)->handleEvent(READ_EVENT);
				continue;
			}

			if(FD_ISSET((iter->first)->getSocket(), &fWrite))
			{
				(iter->first)->handleEvent(WRITE_EVENT);
				continue;
			}

			if(FD_ISSET((iter->first)->getSocket(), &fExcept))
			{
				(iter->first)->handleEvent(EXCEPT_EVENT);
				continue;
			}
		}
	}

}