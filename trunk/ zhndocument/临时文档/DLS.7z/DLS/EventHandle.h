#ifndef EVENTHANDLE_20110526
#define EVENTHANDLE_20110526

#include <WinSock2.h>
#include "Reactor.h"
#include "EventType.h"


class EventHandle
{
public:
	size_t handleEvent(EventType eveType)
	{

	}

	virtual SOCKET getSocket() = 0;
}


#endif