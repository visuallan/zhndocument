#include "ReactorImpl.h"

ReactorImpl::ReactorImpl()
{

}

ReactorImpl::~ReactorImpl()
{

}