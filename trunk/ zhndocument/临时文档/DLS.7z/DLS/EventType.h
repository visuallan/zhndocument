#ifndef EVENTTYPE_20110526
#define EVENTTYPE_20110526

typedef unsigned int EventType;

#define READ_EVENT 0x1
#define WRITE_EVENT 0x2
#define EXCEPT_EVENT 0x4

#endif