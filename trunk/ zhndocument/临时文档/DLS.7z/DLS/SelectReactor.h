#ifndef SELECTREACTOR_20110526 
#define SELECTREACTOR_20110526

#include <map>
#include <WinSock2.h>

#include "Reactor.h"
#include "ReactorImpl.h"
#include "EventHandle.h"

using namespace std;

class SelectReactor: public ReactorImpl
{
public:
	SelectReactor()
	{

	}

	~SelectReactor()
	{

	}

public:
	void addEventHandle(EventHandle* eveHandle, EventType eveType);

	void removeEventHandle(EventHandle* eveHandle);

	void run();

private:
	map<EventHandle*, EventType> eveHandleMap;
}


#endif