#include <WinSock2.h>
#include <iostream>

#include "Reactor.h"
#include "AcceptHandle.h"

using namespace std;

int main()
{
	WSADATA wsaData;
	WSAStartup(MAKEWORD(2, 2), &wsaData);

	AcceptHandle acceptor("127.0.0.1", 8888);

	Reactor::getInstance()->run();

	return EXIT_SUCCESS;
}