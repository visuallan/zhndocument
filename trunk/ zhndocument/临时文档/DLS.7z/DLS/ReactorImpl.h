#ifndef	REACTORIMPL_20110526 
#define REACTORIMPL_20110526

#include "Reactor.h"
#include "EventHandle.h"

class ReactorImpl
{
public:
	ReactorImpl();
		
public:
	virtual void addEventHandle(EventHandle* eveHandle, EventType eveType) = 0;

	virtual void removeEventHandle(EventHandle* eveHandle) = 0;

	virtual void run() = 0;


public:
	~ReactorImpl();
}


#endif