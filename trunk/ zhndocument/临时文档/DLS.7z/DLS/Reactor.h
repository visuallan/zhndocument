#ifndef	REACTOR_20110526 
#define REACTOR_20110526

#include "EventHandle.h"
#include "ReactorImpl.h"
#include "SelectReactor.h"
#include "EventType.h"

class Reactor
{
public:
	static Reactor* getInstance();

public:
	Reactor();

	~Reactor();

public:
	void run();

	void addEventHandle(EventHandle* eveHandle, EventType eveType);

	void removeEventHandle(EventHandle* eveHandle);

public:
	ReactorImpl* pReactorImpl;
}


#endif