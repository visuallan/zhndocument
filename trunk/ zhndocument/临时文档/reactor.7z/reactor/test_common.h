#ifndef REACTOR_TEST_COMMON_H_
#define REACTOR_TEST_COMMON_H_

#include "reactor.h"

#ifdef _WIN32
#define close(handle) closesocket(handle)
#define strncasecmp   _strnicmp
#pragma warning(disable: 4996)
#endif

/// �ж�ָ��handle�Ƿ�Ϊ�Ϸ�handle
extern bool IsValidHandle(SOCKET handle)
{
    return handle != INVALID_SOCKET;
}

/// ����socket error
extern void ReportSocketError(const char * msg)
{
    fprintf(stderr, "%s error: %d\n", msg, WSAGetLastError());
}

#endif // REACTOR_TEST_COMMON_H_
