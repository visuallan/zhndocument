/* egp.c - egp */

#include <conf.h>
#include <kernel.h>
#include <network.h>

/*------------------------------------------------------------------------
 * egp  --  Do the Exterior Gateway Protocol
 *------------------------------------------------------------------------
 */
PROCESS egp()
{
	return OK;
}
