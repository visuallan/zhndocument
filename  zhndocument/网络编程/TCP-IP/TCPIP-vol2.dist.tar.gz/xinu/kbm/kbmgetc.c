
#include <conf.h>
#include <kernel.h>
#include <io.h>

/*------------------------------------------------------------------------
 *  kbmgetc -- read a character from the physical keyboard
 *------------------------------------------------------------------------
 */
kbmgetc(struct devsw *pdev )
{
	return SYSERR;
}


/*------------------------------------------------------------------------
 *  kbmread -- read from the physical keyboard
 *------------------------------------------------------------------------
 */
kbmread(struct devsw *pdev, char *buff, unsigned count)
{
	return SYSERR;
}
