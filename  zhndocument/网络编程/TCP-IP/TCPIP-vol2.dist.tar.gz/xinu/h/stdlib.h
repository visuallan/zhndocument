/* stdlib.h */

#ifndef	_STDLIB_H_
#define _STDLIB_H_

int	atoi(const char *);

#endif /* _STDLIB_H_ */
