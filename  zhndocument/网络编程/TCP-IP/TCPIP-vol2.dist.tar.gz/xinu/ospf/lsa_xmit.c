/* lsa_xmit.c - lsa_xmit */

#include <conf.h>
#include <kernel.h>
#include <network.h>
#include <ospf.h>

/*------------------------------------------------------------------------
 *  lsa_xmit - transmit pending Database Description packets
 *------------------------------------------------------------------------
 */
int
lsa_xmit(struct ospf_if *pif, struct ospf_nb *pnb)
{
}
