/* ipdoopts.c - ipdoopts */

#include <conf.h>
#include <kernel.h>
#include <network.h>

/*------------------------------------------------------------------------
 *  ipdoopts - do gateway handling of IP options
 *------------------------------------------------------------------------
 */
int
ipdoopts(struct netif *pni, struct ep *pep)
{
	return OK;	/* not implemented yet */
}
